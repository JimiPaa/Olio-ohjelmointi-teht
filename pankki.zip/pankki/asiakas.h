#ifndef ASIAKAS_H
#define ASIAKAS_H

class Asiakas
{
public:
    Asiakas();
};

#endif // ASIAKAS_H
